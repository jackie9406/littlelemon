//
//  LittleLemonApp.swift
//  LittleLemonApp
//
//  Created by Jacqueline Ford on 4/21/2023.
//

import SwiftUI

@main
struct LittleLemonApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            OnboardingView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
