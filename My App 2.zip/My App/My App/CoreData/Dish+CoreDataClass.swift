//
//  Dish+CoreDataClass.swift
//  LittleLemonApp
//
//  Created by Jacqueline Ford on 4/21/2023.
//

import Foundation
import CoreData

@objc(Dish)
public class Dish: NSManagedObject {

}
