//
//  CustomColor.swift
//  LittleLemonApp
//
//  Created by Hassan Haidar on 13/03/2023.
//

import SwiftUI

struct CustomColor {
    static let darkGreen = Color("DarkGreen")
    static let lemonYellow = Color("LemonYellow")
    static let buttonBackground = Color("ColorButtonBackground")
}
