//
//  Components.swift
//  LittleLemonApp
//
//  Created by Hassan Haidar on 13/03/2023.
//

import SwiftUI

struct ButtonWithBorder: View {
    let label: String
    let action: () -> Void
    
    let backgroundColor: Color = Color.white
    let textColor: Color = CustomColor.darkGreen
    let borderStrokeColor: Color = CustomColor.darkGreen
    let cornerRadius: CGFloat = 8
    let borderStrokeWidth: CGFloat = 2
    
    var body: some View {
        Button(action: action) {
            Text(label)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(textColor)
                .padding(EdgeInsets(top: 12, leading: 12, bottom: 12, trailing: 12))
                .background(backgroundColor)
                .overlay(
                    RoundedRectangle(cornerRadius: cornerRadius).stroke(borderStrokeColor, lineWidth: borderStrokeWidth))
        }
    }
}

struct ButtonWithFilledColor: View {
    
    let label: String
    let backgroundColor: Color
    let textColor: Color
    let cornerRadius: CGFloat
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(label)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(textColor)
                .padding(EdgeInsets(top: 12, leading: 16, bottom: 12, trailing: 12))
                .background(backgroundColor)
                .cornerRadius(cornerRadius)
        }
    }
}

struct TextFieldWithBorder: View {
    let textLabel: String
    let textFieldLabel: String
    let textInput: Binding<String>
    
    var body: some View {
        VStack(alignment: HorizontalAlignment.leading) {
            Text(textLabel).foregroundColor(CustomColor.darkGreen)
            TextField(textFieldLabel, text: textInput)
            // option 1:
            // .padding()
            // .textFieldStyle(PlainTextFieldStyle())
            // .overlay(RoundedRectangle(cornerRadius: 5).stroke(lineWidth: 1))
            // option 2:
                .frame(height: 52)
                .padding(EdgeInsets(top: 0, leading: 6, bottom: 0, trailing: 6))
                .cornerRadius(5)
                .overlay(RoundedRectangle(cornerRadius: 5).stroke(lineWidth: 1))
        }
    }
}

struct LittleLemonTitleBar: View {
    let action: () -> Void = {}
    
    var body: some View {
        ZStack {
            Image("Logo")
            HStack() {
                Spacer()
                Image("Profile")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 24))
            }
        }
    }
}

struct HeroSection: View {
    var body: some View {
        VStack(alignment: HorizontalAlignment.leading) {
            Text("Little Lemon").foregroundColor(CustomColor.lemonYellow)
                .font(.system(size: 48))
                .padding(EdgeInsets(top: 8, leading: 12, bottom: 0, trailing: 0))
            
            HStack {
                VStack(alignment: HorizontalAlignment.leading) {
                    Text("Chicago")
                        .font(.system(size: 32))
                        .foregroundColor(Color.white)
                        .padding(EdgeInsets(top: 0, leading: 12, bottom: 0, trailing: 0))
                    Spacer()
                    Text("We are a family owned Mediterranean restaurant, focused on traditional recipes served with a modern twist.")
                        .foregroundColor(Color.white)
                        .padding(EdgeInsets(top: 0, leading: 12, bottom: 36, trailing: 0))
                }
                VStack {
                    Spacer()
                    Image("Hero_image")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 140, height: 171)
                        .cornerRadius(12)
                        .padding(EdgeInsets(top: 12, leading: 0, bottom: 28, trailing: 8))
                }
            }
            VStack(alignment: HorizontalAlignment.leading) {
                
                
            }
        }
        .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: 300)
        .background(CustomColor.darkGreen)
    }
}

struct CheckboxWithLabel: View {
    @Binding var isChecked: Bool
    let label: String
    
    var body: some View {
        Button(action: {
            self.isChecked = !self.isChecked
        }) {
            HStack(alignment: .center, spacing: 10) {
                ZStack {
                    Rectangle()
                        .fill(self.isChecked ? CustomColor.darkGreen : Color.white)
                        .frame(width: 30, height: 30, alignment: .center)
                        .cornerRadius(5)
                        .overlay(
                            RoundedRectangle(cornerRadius: 5)
                                .stroke(CustomColor.darkGreen, lineWidth: 1))
                    if isChecked {
                        Image(systemName: "checkmark")
                            .foregroundColor(Color.white)
                    }
                }
                Text(label).font(.system(size: 14, weight: .regular))
            }
        }
        .foregroundColor(Color.black)
    }
}
