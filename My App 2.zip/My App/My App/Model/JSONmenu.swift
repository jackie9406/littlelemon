//
//  JSONmenu.swift
//  LittleLemonApp
//
//  Created by Jacqueline Ford on 4/21/2023.
//

import Foundation

struct JSONMenu: Codable {
    let menuList: [MenuItem]
    
    enum CodingKeys: String, CodingKey {
        case menuList = "menu"
    }
}
